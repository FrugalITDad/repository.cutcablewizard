import xbmc, xbmcgui, xbmcaddon, xbmcvfs, os, json, datetime, ssl, urllib.request

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
ADDON      = xbmcaddon.Addon()
HOME       = xbmcvfs.translatePath("special://home/")
ADDON_DATA = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

MANIFEST_URL          = "https://raw.githubusercontent.com/FrugalITDad/repository.cutcablewizard/main/builds.json"
FIRSTRUN_FILE         = os.path.join(HOME, 'firstrun.txt')
INSTALLED_FILE        = os.path.join(HOME, 'installed_version.txt')
LAST_CHECK_FILE       = os.path.join(HOME, 'last_update_check.txt')
FIRSTRUN_STEPS_FILE   = os.path.join(HOME, 'firstrun_steps.txt')


# Seconds to wait after boot before starting First Run Setup.
# Gives Aeon Nox Silvo time to finish building its menu shortcuts.
FIRSTRUN_BOOT_DELAY = 45


# ---------------------------------------------------------------------------
# Shared Helpers
# ---------------------------------------------------------------------------
def set_kodi_setting(setting, value):
    xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Settings.SetSettingValue",
        "params": {"setting": setting, "value": value},
        "id": 1
    }))


def is_addon_installed(addon_id):
    """Returns True if the given addon is installed and enabled in Kodi."""
    result = xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "method": "Addons.GetAddonDetails",
        "params": {"addonid": addon_id, "properties": ["enabled"]},
        "id": 1
    }))
    try:
        data = json.loads(result)
        return 'error' not in data and data.get('result', {}).get('addon', {}).get('enabled', False)
    except Exception:
        return False


def is_skin_busy(monitor):
    """
    Returns True while Kodi's skin is still loading or a modal is active.
    Also returns True if Kodi is scanning the library.
    """
    return (
        xbmc.getCondVisibility("Window.IsActive(busydialog)") or
        xbmc.getCondVisibility("Window.IsActive(10101)") or
        xbmc.getCondVisibility("Library.IsScanningVideo")
    )


def wait_for_settings_dialog(monitor):
    """Block until the addon settings dialog is dismissed."""
    xbmc.sleep(2000)
    while xbmc.getCondVisibility("Window.IsActive(addonsettings)"):
        if monitor.waitForAbort(1):
            break


def wait_for_trakt_auth(monitor):
    """
    Trakt-specific wait that handles three phases:

    Phase 1 - Settings window:
        Wait for the Trakt settings dialog to close. The user may close
        it without authorizing (fine), or Trakt may close it automatically
        when the user clicks Authorize.

    Phase 2 - Authorization window:
        After settings close, Trakt opens a custom device-code window.
        We use System.HasModalDialog to detect ANY modal appearing within
        8 seconds - this catches Trakt's auth window regardless of its ID.
        Checking specific window IDs is unreliable as Trakt uses a custom
        addon window that does not match standard Kodi dialog IDs.
        Once detected, we wait for it to fully clear before continuing.

    Phase 3 - Confirmation prompt:
        Trakt authorization requires visiting trakt.tv/activate in a browser.
        We show an OK prompt so the user controls when first-run continues.
    """
    # Phase 1: wait for settings window to close
    xbmc.sleep(2000)
    while xbmc.getCondVisibility("Window.IsActive(addonsettings)"):
        if monitor.waitForAbort(1):
            return

    # Phase 2a: poll for up to 8 seconds for Trakt's auth window to appear.
    # Short 500ms intervals so we react quickly once it opens.
    # abortRequested() is used instead of waitForAbort(0) — a zero timeout
    # is undefined in Kodi's Python API and on Android can return True
    # immediately, falsely flagging an abort that then causes all subsequent
    # waitForAbort() calls (including the Step 5 countdown) to exit early.
    auth_appeared = False
    for _ in range(16):
        if monitor.abortRequested():
            return
        if xbmc.getCondVisibility("System.HasModalDialog(true)"):
            auth_appeared = True
            break
        xbmc.sleep(500)

    # Phase 2b: auth window appeared - wait for it to fully close.
    # 5 minute timeout matches Trakt device-code expiry.
    if auth_appeared:
        AUTH_TIMEOUT = 300
        elapsed = 0
        while elapsed < AUTH_TIMEOUT:
            if not xbmc.getCondVisibility("System.HasModalDialog(true)"):
                break
            if monitor.waitForAbort(2):
                return
            elapsed += 2

    # Phase 3: show confirmation so the user controls when first-run continues.
    # Trakt requires opening trakt.tv/activate on another device - the user
    # needs time to complete that step before setup moves on.
    xbmcgui.Dialog().ok(
        "Setup (4/5): Trakt",
        "Trakt authorization window has closed.\n\n"
        "If you still need to authorize in your browser, do that now.\n\n"
        "Tap [B]OK[/B] when you are ready to continue setup."
    )


def get_json(url):
    try:
        context = ssl._create_unverified_context()
        req = urllib.request.Request(url, headers={'User-Agent': 'Kodi-Wizard'})
        with urllib.request.urlopen(req, context=context, timeout=15) as r:
            return json.loads(r.read().decode('utf-8'))
    except Exception:
        return None


def get_installed_info():
    """
    Returns (build_id, version) from installed_version.txt.
    File format: build_id|version
    Returns (None, None) when no recognised build is installed.
    """
    if not os.path.exists(INSTALLED_FILE):
        return None, None
    try:
        with open(INSTALLED_FILE, 'r') as f:
            data = f.read().strip()
        if '|' in data:
            build_id, version = data.split('|', 1)
            return build_id.strip(), version.strip()
    except Exception:
        pass
    return None, None


# ---------------------------------------------------------------------------
# First Run Setup
# ---------------------------------------------------------------------------
def read_firstrun_steps():
    """
    Reads firstrun_steps.txt and returns a set of allowed step names,
    or None if the file does not exist (meaning run all steps).

    The file is written by install_build() in default.py when a build
    has a firstrun_steps list in builds.json (e.g. the admin build).
    Regular builds do not write this file so all steps always run.

    Step names must match the keys used in run_first_time_setup():
      device_name, weather, subtitles, iptv_sync,
      trakt, scrubs_v2, iagl, buffer
    """
    if not os.path.exists(FIRSTRUN_STEPS_FILE):
        return None   # No filter — run all steps
    try:
        with open(FIRSTRUN_STEPS_FILE, 'r') as f:
            steps = {s.strip() for s in f.read().strip().split(',') if s.strip()}
        xbmc.log(f"[CutCableWizard] firstrun_steps filter: {steps}", xbmc.LOGINFO)
        return steps if steps else None
    except Exception:
        return None   # Unreadable — safe fallback is to run all steps


def run_first_time_setup(monitor):
    """
    Runs the interactive setup wizard.
    Called only when firstrun.txt exists (written by install_build).
    The trigger file is deleted ONLY after the full setup completes,
    so a crash mid-setup will re-trigger setup on the next Kodi boot.

    If firstrun_steps.txt exists, only the listed steps are shown.
    The step counter (X/Y) is computed from the active steps so the
    numbering is always correct regardless of which steps are skipped.
    """

    # ── Wait for Aeon Nox Silvo to finish building menu shortcuts ─────────
    xbmc.log("[CutCableWizard] First Run: waiting 45s for skin to settle.", xbmc.LOGINFO)
    if monitor.waitForAbort(FIRSTRUN_BOOT_DELAY):
        return  # Kodi shutting down

    # Re-check trigger in case a force-close happened during the wait
    if not os.path.exists(FIRSTRUN_FILE):
        return

    # ── Wait for any busy/loading states to clear ─────────────────────────
    while is_skin_busy(monitor):
        if monitor.waitForAbort(5):
            return

    # ── Wait for any addon auth prompts to clear ──────────────────────────
    # Some addons (e.g. JellyCon on the Pro build) show a login dialog
    # immediately on boot. We hold setup back until all modal dialogs are
    # gone so the first run questions never appear on top of an auth prompt.
    # 10 minute ceiling handles slow logins; logs every 30s so it is visible
    # in the Kodi log if something is unexpectedly blocking.
    AUTH_WAIT_CEILING = 600  # 10 minutes
    auth_wait_elapsed = 0
    while xbmc.getCondVisibility("System.HasModalDialog(true)"):
        if monitor.waitForAbort(2):
            return
        auth_wait_elapsed += 2
        if auth_wait_elapsed % 30 == 0:
            xbmc.log(
                f"[CutCableWizard] First Run: waiting for modal dialog to clear "
                f"({auth_wait_elapsed}s elapsed).", xbmc.LOGINFO
            )
        if auth_wait_elapsed >= AUTH_WAIT_CEILING:
            xbmc.log(
                "[CutCableWizard] First Run: modal dialog wait exceeded 10 minutes, "
                "proceeding anyway.", xbmc.LOGWARNING
            )
            break

    xbmc.executebuiltin('ReplaceWindow(10000)')
    dialog = xbmcgui.Dialog()

    # ── Determine which steps are active for this build ───────────────────
    # ALL_STEPS defines the canonical order. read_firstrun_steps() returns
    # a set of allowed step names from firstrun_steps.txt, or None (= all).
    # The step counter "X/Y" is computed from the active list so it is always
    # correct even when steps are skipped for the admin build.
    ALL_STEPS = ['device_name', 'weather', 'subtitles', 'iptv_sync',
                 'trakt', 'scrubs_v2', 'iagl', 'buffer']

    allowed   = read_firstrun_steps()   # set of names or None
    active    = [s for s in ALL_STEPS if allowed is None or s in allowed]
    total     = len(active)

    def n(step_name):
        """Returns the 1-based display index of step_name within active steps."""
        return active.index(step_name) + 1 if step_name in active else 0

    xbmc.log(f"[CutCableWizard] First Run active steps ({total}): {active}", xbmc.LOGINFO)

    # ── Step: Device Name ─────────────────────────────────────────────────
    if 'device_name' in active:
        name = dialog.input(
            f"Setup ({n('device_name')}/{total}): Device Name",
            defaultt="Kodi-FireTV"
        ).strip()
        if name:
            set_kodi_setting("services.devicename", name)

    # ── Step: Weather ─────────────────────────────────────────────────────
    if 'weather' in active:
        if dialog.yesno(
            f"Setup ({n('weather')}/{total}): Weather",
            "Would you like to configure your weather location?"
        ):
            xbmc.executebuiltin("Addon.OpenSettings(weather.gismeteo)")
            wait_for_settings_dialog(monitor)

    # ── Step: Subtitles ───────────────────────────────────────────────────
    if 'subtitles' in active:
        if dialog.yesno(
            f"Setup ({n('subtitles')}/{total}): Subtitles",
            "Enable automatic subtitles?"
        ):
            set_kodi_setting("subtitles.enabled", True)

    # ── Step: IPTV Guide Sync ─────────────────────────────────────────────
    # Runs before Trakt so the 145s countdown completes with no interruptions.
    if 'iptv_sync' in active:
        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.iptv.merge/?mode=run)")
        dp = xbmcgui.DialogProgress()
        dp.create(
            f"Setup ({n('iptv_sync')}/{total}): IPTV Guide Sync",
            "Syncing Live TV Guide..."
        )
        total_time = 145
        for i in range(total_time):
            if monitor.waitForAbort(1) or dp.iscanceled():
                break
            percent   = int((i / float(total_time)) * 100)
            remaining = total_time - i
            dp.update(percent, f"Finalizing IPTV Guide setup...\nTime remaining: {remaining}s")
        dp.close()

    # ── Step: Trakt ───────────────────────────────────────────────────────
    if 'trakt' in active:
        if is_addon_installed("script.trakt"):
            if dialog.yesno(
                f"Setup ({n('trakt')}/{total}): Trakt",
                "Would you like to authorize your Trakt account?"
            ):
                xbmc.executebuiltin("Addon.OpenSettings(script.trakt)")
                wait_for_trakt_auth(monitor)
        else:
            xbmc.log("[CutCableWizard] script.trakt not installed – skipping Trakt step.", xbmc.LOGINFO)

    # ── Step: Scrubs V2 Trakt ─────────────────────────────────────────────
    if 'scrubs_v2' in active:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.scrubsv2)"):
            if dialog.yesno(
                f"Setup ({n('scrubs_v2')}/{total}): Scrubs V2",
                "Would you like to authorize Trakt inside Scrubs V2?"
            ):
                dialog.ok(
                    "Scrubs V2 - Trakt Authorization",
                    "The Scrubs V2 Tools menu will now open.\n\n"
                    "Select [B]Trakt: Authorize[/B] from the list, complete the "
                    "authorization, then press Back to continue setup."
                )
                xbmc.executebuiltin(
                    'ActivateWindow(Videos,"plugin://plugin.video.scrubsv2/?action=tools_menu",return)'
                )
                while xbmc.getCondVisibility("Window.IsActive(videos)"):
                    if monitor.waitForAbort(1):
                        break
        else:
            xbmc.log("[CutCableWizard] plugin.video.scrubsv2 not installed – skipping Scrubs V2 step.", xbmc.LOGINFO)

    # ── Step: IAGL Archive.org ────────────────────────────────────────────
    if 'iagl' in active:
        if xbmc.getCondVisibility("System.HasAddon(plugin.program.iagl)"):
            if dialog.yesno(
                f"Setup ({n('iagl')}/{total}): IAGL Gaming",
                "Would you like to configure Archive.org for the IAGL Gaming addon?\n\n"
                "You will need your Archive.org account credentials."
            ):
                dialog.ok(
                    "IAGL - Archive.org Setup",
                    "The IAGL addon settings will now open.\n\n"
                    "Navigate to the [B]Downloading[/B] section on the left and "
                    "enter your Archive.org username and password, then close "
                    "settings to continue."
                )
                xbmc.executebuiltin("Addon.OpenSettings(plugin.program.iagl)")
                wait_for_settings_dialog(monitor)
        else:
            xbmc.log("[CutCableWizard] plugin.program.iagl not installed – skipping IAGL step.", xbmc.LOGINFO)

    # ── Step: EZ Maintenance+ Buffer Optimization ─────────────────────────
    if 'buffer' in active:
        if xbmc.getCondVisibility("System.HasAddon(script.ezmaintenanceplus)"):
            if dialog.yesno(
                f"Setup ({n('buffer')}/{total}): Buffer Optimization",
                "Would you like to optimize the buffer size for this device?\n\n"
                "This is recommended for the best streaming performance."
            ):
                dialog.ok(
                    "Buffer Optimization",
                    "The EZ Maintenance+ menu will now open.\n\n"
                    "Select [B]ADVANCED SETTINGS (BUFFER SIZE)[/B] from the menu, "
                    "then choose [B]USE OPTIMAL[/B] to apply the best buffer "
                    "settings for this device.\n\n"
                    "Close the menu when done to complete setup."
                )
                xbmc.executebuiltin("RunAddon(script.ezmaintenanceplus)")
                xbmc.sleep(2000)
                while (xbmc.getCondVisibility("Window.IsActive(programs)") or
                       xbmc.getCondVisibility("System.HasModalDialog(true)")):
                    if monitor.waitForAbort(1):
                        break
        else:
            xbmc.log("[CutCableWizard] script.ezmaintenanceplus not installed – skipping buffer step.", xbmc.LOGINFO)

    # ── Cleanup & finish ──────────────────────────────────────────────────
    for f in [FIRSTRUN_FILE, FIRSTRUN_STEPS_FILE]:
        try:
            if os.path.exists(f):
                os.remove(f)
        except Exception:
            pass

    xbmc.executebuiltin('SaveSceneSettings')
    dialog.ok(
        "Setup Complete",
        "Your CordCutter build is fully configured and ready to use!\n\n"
        "[B]Note:[/B] Your weather location will not appear until the next time you restart Kodi.\n\n"
        "Enjoy your new setup."
    )
    xbmc.log("[CutCableWizard] First Run setup complete.", xbmc.LOGINFO)


# ---------------------------------------------------------------------------
# Daily Update Check
# ---------------------------------------------------------------------------
def should_check_for_updates():
    """
    Returns True once per day.
    Stores the last-checked date in last_update_check.txt.
    """
    today = datetime.date.today().isoformat()   # e.g. "2025-11-01"
    if os.path.exists(LAST_CHECK_FILE):
        try:
            with open(LAST_CHECK_FILE, 'r') as f:
                last = f.read().strip()
            if last == today:
                return False   # Already checked today
        except Exception:
            pass
    # Write today's date
    try:
        with open(LAST_CHECK_FILE, 'w') as f:
            f.write(today)
    except Exception:
        pass
    return True


def run_update_check():
    """
    Fetches the manifest and prompts the user if a newer version of their
    installed build is available. Runs silently if no build is installed
    or if the manifest cannot be reached.
    """
    build_id, installed_version = get_installed_info()
    if not build_id or not installed_version:
        return   # Nothing installed to compare

    manifest = get_json(MANIFEST_URL)
    if not manifest:
        xbmc.log("[CutCableWizard] Update check: could not reach manifest.", xbmc.LOGWARNING)
        return

    builds = manifest.get('builds', [])
    current_build = next((b for b in builds if b['id'] == build_id), None)
    if not current_build:
        xbmc.log(f"[CutCableWizard] Update check: build '{build_id}' not found in manifest.", xbmc.LOGWARNING)
        return

    latest_version = current_build.get('version', '')
    if not latest_version or latest_version == installed_version:
        xbmc.log(f"[CutCableWizard] Update check: '{build_id}' is up to date (v{installed_version}).", xbmc.LOGINFO)
        return

    xbmc.log(f"[CutCableWizard] Update available: {build_id} v{installed_version} → v{latest_version}", xbmc.LOGINFO)

    # Prompt the user
    if xbmcgui.Dialog().yesno(
        "Build Update Available",
        f"A new version of [B]{current_build['name']}[/B] is available!\n\n"
        f"  Installed : v{installed_version}\n"
        f"  Available : v{latest_version}\n\n"
        "Would you like to update now?\n"
        "(You can also update later via the CutCable Wizard.)"
    ):
        # Launch the wizard so install_build handles the full process
        xbmc.executebuiltin(f"RunAddon(plugin.program.cutcablewizard)")


# ---------------------------------------------------------------------------
# Service Entry Point
# ---------------------------------------------------------------------------
def run_service():
    monitor = xbmc.Monitor()
    xbmc.log("[CutCableWizard] Service started.", xbmc.LOGINFO)

    # ── First Run setup (only when a build was just installed) ──────────
    if os.path.exists(FIRSTRUN_FILE):
        run_first_time_setup(monitor)

    # ── Daily update check (skipped when first run setup is pending) ─────
    elif should_check_for_updates():
        # Give Kodi a moment to fully load before showing any dialog
        if not monitor.waitForAbort(15):
            run_update_check()

    # ── Keep the service alive ────────────────────────────────────────────
    # The service must stay running so Kodi doesn't mark the addon as broken.
    while not monitor.waitForAbort(3600):
        pass

    xbmc.log("[CutCableWizard] Service stopped.", xbmc.LOGINFO)


if __name__ == '__main__':
    run_service()