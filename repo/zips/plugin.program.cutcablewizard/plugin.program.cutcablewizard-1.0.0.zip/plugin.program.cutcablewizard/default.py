import xbmcgui

dialog = xbmcgui.Dialog()
dialog.ok("CutCableWizard", "CutCableWizard installed.\n\nNext step: build selection and post-setup wizard.")
